const KEY = "egrow-store-v1";
const STATUSES = ["جديد", "قيد الشحن", "تم التسليم", "ملغي"];
const LOW_STOCK = 5;
const DAY = 86400000;

let state = load();
let editingProductId = null;

function load() {
  try {
    const s = JSON.parse(localStorage.getItem(KEY));
    if (s && Array.isArray(s.products) && Array.isArray(s.orders)) return s;
  } catch {}
  return { products: [], orders: [] };
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {}
}

const $ = (id) => document.getElementById(id);
const money = (n) => Number(n || 0).toLocaleString("ar-MA", { maximumFractionDigits: 2 }) + " د.م.";
const fmtDate = (t) => new Date(t).toLocaleDateString("ar-MA", { day: "numeric", month: "short" });
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const orderTotal = (o) => o.items.reduce((s, i) => s + i.price * i.qty, 0);

/* ---------- التنقل ---------- */
document.querySelectorAll(".nav").forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll(".nav").forEach((x) => x.classList.toggle("active", x === b));
    document.querySelectorAll(".view").forEach((v) => v.classList.add("hidden"));
    $("view-" + b.dataset.view).classList.remove("hidden");
    render();
  };
});
document.querySelectorAll("[data-close]").forEach((b) => (b.onclick = () => b.closest("dialog").close()));

/* ---------- لوحة التحكم ---------- */
function renderDashboard() {
  const valid = state.orders.filter((o) => o.status !== "ملغي");
  $("s-sales").textContent = money(valid.reduce((s, o) => s + orderTotal(o), 0));
  $("s-orders").textContent = state.orders.length;
  $("s-new").textContent = state.orders.filter((o) => o.status === "جديد").length;
  $("s-low").textContent = state.products.filter((p) => p.stock <= LOW_STOCK).length;

  // مبيعات آخر 7 أيام
  const days = [];
  const today = new Date(); today.setHours(0, 0, 0, 0);
  for (let i = 6; i >= 0; i--) days.push(today.getTime() - i * DAY);
  const sums = days.map((d) =>
    valid.filter((o) => o.date >= d && o.date < d + DAY).reduce((s, o) => s + orderTotal(o), 0));
  const max = Math.max(...sums, 1);
  $("chart").innerHTML = days.map((d, i) =>
    `<div class="bar"><b>${sums[i] ? Math.round(sums[i]) : ""}</b><i style="height:${(sums[i] / max) * 130}px"></i><span>${fmtDate(d)}</span></div>`).join("");

  // الأكثر مبيعًا
  const tally = {};
  valid.forEach((o) => o.items.forEach((i) => (tally[i.name] = (tally[i.name] || 0) + i.qty)));
  const top = Object.entries(tally).sort((a, b) => b[1] - a[1]).slice(0, 5);
  $("top-products").innerHTML = top.length
    ? top.map(([n, q]) => `<li>${esc(n)} — <strong>${q}</strong> قطعة</li>`).join("")
    : "<li>لا توجد مبيعات بعد</li>";
}

/* ---------- المنتجات ---------- */
function renderProducts() {
  const q = $("search-products").value.trim().toLowerCase();
  const list = state.products.filter((p) => !q || (p.name + " " + p.category).toLowerCase().includes(q));
  $("products-body").innerHTML = list.map((p) => `
    <tr>
      <td>${esc(p.name)}</td>
      <td>${esc(p.category || "—")}</td>
      <td>${money(p.price)}</td>
      <td class="${p.stock <= LOW_STOCK ? "low" : ""}">${p.stock}${p.stock <= LOW_STOCK ? " ⚠️" : ""}</td>
      <td><div class="actions">
        <button class="small secondary" data-edit="${p.id}">تعديل</button>
        <button class="small del" data-del="${p.id}">حذف</button>
      </div></td>
    </tr>`).join("");
  $("products-empty").classList.toggle("hidden", list.length > 0);
}
$("search-products").oninput = renderProducts;
$("products-body").onclick = (e) => {
  const edit = e.target.dataset.edit, del = e.target.dataset.del;
  if (edit) openProduct(edit);
  if (del && confirm("حذف هذا المنتج؟")) {
    state.products = state.products.filter((p) => p.id !== del);
    save(); render();
  }
};

function openProduct(id) {
  editingProductId = id || null;
  const p = state.products.find((x) => x.id === id);
  $("dlg-product-title").textContent = p ? "تعديل المنتج" : "منتج جديد";
  $("p-name").value = p ? p.name : "";
  $("p-category").value = p ? p.category : "";
  $("p-price").value = p ? p.price : "";
  $("p-stock").value = p ? p.stock : "";
  $("dlg-product").showModal();
}
$("btn-add-product").onclick = () => openProduct();
$("form-product").onsubmit = () => {
  const data = {
    name: $("p-name").value.trim(),
    category: $("p-category").value.trim(),
    price: parseFloat($("p-price").value) || 0,
    stock: parseInt($("p-stock").value, 10) || 0,
  };
  if (!data.name) return;
  if (editingProductId) Object.assign(state.products.find((p) => p.id === editingProductId), data);
  else state.products.push({ id: uid(), ...data });
  save(); render();
};

/* ---------- الطلبات ---------- */
const badgeClass = { "جديد": "new", "قيد الشحن": "ship", "تم التسليم": "done", "ملغي": "cancel" };

function renderOrders() {
  const f = $("filter-status").value;
  const list = state.orders.filter((o) => !f || o.status === f).sort((a, b) => b.date - a.date);
  $("orders-body").innerHTML = list.map((o) => `
    <tr>
      <td>${esc(o.num)}</td>
      <td>${fmtDate(o.date)}</td>
      <td>${esc(o.customer)}<br><small>${esc(o.phone || "")}</small></td>
      <td>${o.items.map((i) => `${esc(i.name)} ×${i.qty}`).join("<br>")}</td>
      <td>${money(orderTotal(o))}</td>
      <td><span class="badge ${badgeClass[o.status]}">${o.status}</span></td>
      <td><select data-status="${o.id}">${STATUSES.map((s) => `<option ${s === o.status ? "selected" : ""}>${s}</option>`).join("")}</select></td>
    </tr>`).join("");
  $("orders-empty").classList.toggle("hidden", list.length > 0);
}
$("filter-status").onchange = renderOrders;
$("orders-body").onchange = (e) => {
  const id = e.target.dataset.status;
  if (!id) return;
  const o = state.orders.find((x) => x.id === id);
  const next = e.target.value;
  // إرجاع المخزون عند الإلغاء، وخصمه عند إلغاء الإلغاء
  if (next === "ملغي" && o.status !== "ملغي") adjustStock(o, +1);
  if (o.status === "ملغي" && next !== "ملغي") adjustStock(o, -1);
  o.status = next;
  save(); render();
};
function adjustStock(order, sign) {
  order.items.forEach((i) => {
    const p = state.products.find((x) => x.id === i.pid);
    if (p) p.stock = Math.max(0, p.stock + sign * i.qty);
  });
}

function lineHtml() {
  const opts = state.products.map((p) => `<option value="${p.id}">${esc(p.name)} (${money(p.price)}) – متوفر ${p.stock}</option>`).join("");
  return `<div class="line"><select class="l-prod">${opts}</select><input class="l-qty" type="number" min="1" value="1"><button type="button" class="small del l-rm">✕</button></div>`;
}
function updateOrderTotal() {
  let t = 0;
  document.querySelectorAll("#o-lines .line").forEach((l) => {
    const p = state.products.find((x) => x.id === l.querySelector(".l-prod").value);
    t += (p ? p.price : 0) * (parseInt(l.querySelector(".l-qty").value, 10) || 0);
  });
  $("o-total").textContent = money(t);
}
$("btn-add-order").onclick = () => {
  if (!state.products.length) { alert("أضف منتجًا أولًا من صفحة المنتجات."); return; }
  $("o-customer").value = ""; $("o-phone").value = ""; $("o-error").textContent = "";
  $("o-lines").innerHTML = lineHtml();
  updateOrderTotal();
  $("dlg-order").showModal();
};
$("btn-add-line").onclick = () => { $("o-lines").insertAdjacentHTML("beforeend", lineHtml()); updateOrderTotal(); };
$("o-lines").oninput = updateOrderTotal;
$("o-lines").onclick = (e) => {
  if (e.target.classList.contains("l-rm") && document.querySelectorAll("#o-lines .line").length > 1) {
    e.target.closest(".line").remove(); updateOrderTotal();
  }
};
$("form-order").onsubmit = (e) => {
  // جمع الأسطر ودمج المنتج المكرر
  const wanted = {};
  document.querySelectorAll("#o-lines .line").forEach((l) => {
    const pid = l.querySelector(".l-prod").value;
    const qty = parseInt(l.querySelector(".l-qty").value, 10) || 0;
    if (qty > 0) wanted[pid] = (wanted[pid] || 0) + qty;
  });
  const items = [];
  for (const [pid, qty] of Object.entries(wanted)) {
    const p = state.products.find((x) => x.id === pid);
    if (!p || qty > p.stock) {
      e.preventDefault();
      $("o-error").textContent = `الكمية المطلوبة من "${p ? p.name : "؟"}" أكبر من المخزون.`;
      return;
    }
    items.push({ pid, name: p.name, price: p.price, qty });
  }
  if (!items.length) { e.preventDefault(); $("o-error").textContent = "أضف منتجًا واحدًا على الأقل."; return; }
  const order = {
    id: uid(), num: state.orders.length + 1, date: Date.now(),
    customer: $("o-customer").value.trim(), phone: $("o-phone").value.trim(),
    items, status: "جديد",
  };
  adjustStock(order, -1);
  state.orders.push(order);
  save(); render();
};

$("btn-export").onclick = () => {
  const rows = [["رقم", "التاريخ", "العميل", "الهاتف", "المنتجات", "المبلغ", "الحالة"]];
  state.orders.forEach((o) => rows.push([
    o.num, new Date(o.date).toISOString().slice(0, 10), o.customer, o.phone,
    o.items.map((i) => `${i.name} x${i.qty}`).join(" | "), orderTotal(o), o.status,
  ]));
  const csv = "﻿" + rows.map((r) => r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  a.download = "orders.csv";
  a.click();
  URL.revokeObjectURL(a.href);
};

/* ---------- العملاء ---------- */
function renderCustomers() {
  const map = {};
  state.orders.filter((o) => o.status !== "ملغي").forEach((o) => {
    const k = (o.phone || o.customer).toLowerCase();
    const c = (map[k] ||= { name: o.customer, phone: o.phone, count: 0, total: 0 });
    c.count++; c.total += orderTotal(o);
  });
  const list = Object.values(map).sort((a, b) => b.total - a.total);
  $("customers-body").innerHTML = list.map((c) =>
    `<tr><td>${esc(c.name)}</td><td>${esc(c.phone || "—")}</td><td>${c.count}</td><td>${money(c.total)}</td></tr>`).join("");
  $("customers-empty").classList.toggle("hidden", list.length > 0);
}

/* ---------- بيانات تجريبية / مسح ---------- */
$("btn-demo").onclick = () => {
  if (state.products.length && !confirm("سيتم استبدال بياناتك الحالية. متابعة؟")) return;
  const P = (name, category, price, stock) => ({ id: uid(), name, category, price, stock });
  const products = [
    P("قميص قطني", "ملابس", 120, 25), P("حذاء رياضي", "أحذية", 350, 12),
    P("حقيبة ظهر", "إكسسوارات", 220, 4), P("ساعة ذكية", "إلكترونيات", 590, 8),
    P("سماعة بلوتوث", "إلكترونيات", 180, 3),
  ];
  const names = [["سلمى", "0612345678"], ["يوسف", "0661234567"], ["مريم", "0677889900"], ["أمين", "0655443322"]];
  const orders = [];
  for (let i = 0; i < 10; i++) {
    const p = products[i % products.length], qty = 1 + (i % 2), [c, ph] = names[i % names.length];
    orders.push({
      id: uid(), num: i + 1, date: Date.now() - (i % 7) * DAY - i * 3600000,
      customer: c, phone: ph, items: [{ pid: p.id, name: p.name, price: p.price, qty }],
      status: STATUSES[i % 3],
    });
  }
  state = { products, orders };
  save(); render();
};
$("btn-reset").onclick = () => {
  if (confirm("مسح كل المنتجات والطلبات نهائيًا؟")) { state = { products: [], orders: [] }; save(); render(); }
};

function render() {
  renderDashboard(); renderProducts(); renderOrders(); renderCustomers();
}
render();
